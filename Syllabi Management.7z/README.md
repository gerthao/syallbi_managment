# KanyeWestSuperfans
CS 361 - Kanye West Superfans

# Testing Requirements
+ ensure that google_appengine is in your PYTHONPATH
+ use pip to install/update the following required modules:
    + mock
    + webtest
    + jinja2
    + webapp2
    + pytest
    + pyyaml
+ You can now run tests individually (execute like normal python scripts) or via the /Tests/ folder (see here for details: http://pytest.org/latest/getting-started.html#running-multiple-tests )